package com.ltp.gradesubmission;

import java.util.List;
import java.util.Optional;

public interface GradeService {
    // Return the entire list
    List<Grade> getGrades();

    // Return just one grade
    Optional<Grade> getGrade(String id);

    void deleteGrade(String id);

    void addGrade(Grade grade);

    void updateGrade(Grade grade);
}
