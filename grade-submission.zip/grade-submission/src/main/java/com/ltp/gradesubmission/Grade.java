package com.ltp.gradesubmission;


import org.hibernate.validator.constraints.Range;
import org.springframework.boot.convert.DataSizeUnit;

import java.util.Optional;
import java.util.UUID;
import jakarta.validation.constraints.*;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Grade {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String id;

    @NotBlank(message = "You must supply a name ")
    private String name;
    @NotBlank(message = "Subject cannot be empty")
    private String subject;
    @Range(min = 1, max = 10, message = "Enter grade between 1 and 10")
    private String score;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }


    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

}
