package com.ltp.gradesubmission;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class GradeServiceImpl implements GradeService {
    @Autowired
    private GradeRepository gradeRepository;

    // Return the entire list
    @Override
    public List<Grade> getGrades() {
        return gradeRepository.findAll();
    }

    // Return just one grade
    public Optional<Grade> getGrade(String id) {

        return gradeRepository.findById(id);
    }

    @Override
    public void deleteGrade(String id) {
        gradeRepository.deleteById(id);
    }

    @Override
    public void addGrade(Grade grade) {
        gradeRepository.save(grade);
        //grades.add(grade);
    }

    @Override
    public void updateGrade(Grade grade) {
        gradeRepository.save(grade);
    }

}
