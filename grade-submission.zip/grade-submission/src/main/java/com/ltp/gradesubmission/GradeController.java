package com.ltp.gradesubmission;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.validation.Valid;

@Controller
public class GradeController {

    // Use the interface here, to make sure that the controller
    // only talks to the interface and not to the implementation.
    @Autowired
    GradeService gradeService;

    @GetMapping("/")
    public String getForm(Model model, @RequestParam(required = false) String id) {

        Grade gradeFromList = null;
        if (id != null && !id.isEmpty()) {
             gradeFromList = gradeService.getGrade(id).get();
        }

        Grade grade = gradeFromList != null ? gradeFromList : new Grade();

        model.addAttribute("grade", grade);

        return "form";
    }

    @GetMapping("/grades/grade")
    public String addGrade(Model model) {

        model.addAttribute("grade", new Grade());

        return "form";
    }

    @GetMapping("/grades/delete")
    public String deleteGrade(Model model, @RequestParam(required = true) String id) {
        gradeService.deleteGrade(id);

        return "redirect:/grades";
    }

    @PostMapping("/handleSubmit")
    public String submitForm(@Valid Grade grade, BindingResult bindingResult) {

        if (bindingResult.hasErrors()) {
            return "form";
        }

        Optional<Grade> gradeFetched = gradeService.getGrade(grade.getId());

        if (gradeFetched.isPresent()) {
            Grade gradeFromDB = gradeFetched.get();
            gradeFromDB.setName(grade.getName());
            gradeFromDB.setScore(grade.getScore());
            gradeFromDB.setSubject(grade.getSubject());

            gradeService.updateGrade(gradeFromDB);
        } else {
            gradeService.addGrade(grade);
        }
        return "redirect:/grades";
    }

    @GetMapping("/grades")
    public String getGrades(Model model) {
        model.addAttribute("grades", gradeService.getGrades());
        model.addAttribute("studentName", "Test name");
        return "grades";
    }
}